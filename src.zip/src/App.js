import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Chat from "./pages/Chat";
import Notifications from "./pages/Notifications";
import TaskScheduler from "./pages/TaskScheduler";
import ScrumBoard from "./pages/ScrumBoard";
import Login from "./pages/Login"; // Import your Login component
import Signup from "./pages/Signup"; // Import your Signup component

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />  
        <Route path="/login" element={<Login />} />  {/* Add this route */}
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/task-scheduler" element={<TaskScheduler />} />
        <Route path="/scrum-board" element={<ScrumBoard />} />
      </Routes>
    </Router>
  );
}

export default App;
