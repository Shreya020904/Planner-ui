import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Header.css";

const Header = () => {
  const [username, setUsername] = useState("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUsername = localStorage.getItem("username");
    setUsername(storedUsername || "User");
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("username"); // Clear stored username
    navigate("/login"); // Redirect to login page
  };

  return (
    <div className="header">
      <h1>Planner</h1>
      <div className="user-menu">
        <button className="user-name" onClick={() => setDropdownOpen(!dropdownOpen)}>
          {username} ▼
        </button>
        {dropdownOpen && (
          <div className="dropdown">
            <div onClick={() => console.log("Go to Account")}>Account</div>
            <div onClick={() => console.log("Change Theme")}>Theme</div>
            <div className="logout" onClick={handleLogout}>Logout</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;
