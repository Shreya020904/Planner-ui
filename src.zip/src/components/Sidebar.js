import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "./Sidebar.css";

const Sidebar = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(true);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <button className="toggle-btn" onClick={toggleSidebar}>
        ☰
      </button>
      <div className={`sidebar ${isOpen ? "" : "closed"}`}>
        <ul>
          <li className={location.pathname === "/dashboard" ? "active" : ""}>
            <Link to="/dashboard">Dashboard</Link>
          </li>
          <li className={location.pathname === "/chat" ? "active" : ""}>
            <Link to="/chat">Chat</Link>
          </li>
          <li className={location.pathname === "/notifications" ? "active" : ""}>
            <Link to="/notifications">Notifications</Link>
          </li>
          <li className={location.pathname === "/scrum-board" ? "active" : ""}>
            <Link to="/scrum-board">Scrum Board</Link>
          </li>
          <li className={location.pathname === "/task-scheduler" ? "active" : ""}>
            <Link to="/task-scheduler">Task Scheduler</Link>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Sidebar;
