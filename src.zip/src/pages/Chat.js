import React, { useState, useEffect } from "react";
import { db, auth } from "../firebase";
import { collection, getDocs, onSnapshot, orderBy, query, addDoc, serverTimestamp,setDoc,doc } from "firebase/firestore";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import "./Chat.css";

const Chat = () => {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true); 
  const [searchQuery, setSearchQuery] = useState("");
  const [pinnedContacts, setPinnedContacts] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(null);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "users"));
        let usersList = querySnapshot.docs.map((doc) => doc.data());
    
        // Add AI user manually
        const aiUser = {
          uid: "ai-bot",
          username: "AI Assistant"
        };
        
        usersList.push(aiUser);
        setUsers(usersList);
      } catch (error) {
        console.error("Error fetching users: ", error);
      }
    };

    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setCurrentUser(user);
      }
    });

    fetchUsers();
    return () => unsubscribe();
  }, []);

  const toggleDropdown = (uid) => {
    setDropdownOpen(dropdownOpen === uid ? null : uid);
  };

  const pinContact = (user) => {
    if (!pinnedContacts.some(pinned => pinned.uid === user.uid)) {
      setPinnedContacts([...pinnedContacts, user]);
    }
    setDropdownOpen(null);
  };

  useEffect(() => {
    if (currentUser && selectedUser) {
      const chatId = [currentUser.uid, selectedUser.uid].sort().join("_");
      const chatRef = collection(db, "chats", chatId, "messages");
      const q = query(chatRef, orderBy("timestamp"));

      const unsubscribe = onSnapshot(q, (snapshot) => {
        setMessages(snapshot.docs.map(doc => doc.data()));
      });

      return () => unsubscribe();
    }
  }, [selectedUser, currentUser]);

  const sendMessage = async () => {
    if (newMessage.trim() === "" || !selectedUser) return;
  
    const chatId = [currentUser.uid, selectedUser.uid].sort().join("_");
    const chatRef = collection(db, "chats", chatId, "messages");
  
    // Add user's message to Firestore
    await addDoc(chatRef, {
      sender: currentUser.uid,
      message: newMessage,
      timestamp: serverTimestamp()
    });
  
    // If chatting with AI, generate a response
    if (selectedUser.uid === "ai-bot") {
      const aiResponse = generateAIResponse(newMessage);
  
      setTimeout(async () => {
        await addDoc(chatRef, {
          sender: "ai-bot",
          message: aiResponse,
          timestamp: serverTimestamp()
        });
      }, 1000); // Simulate AI response delay
    }
  
    setNewMessage("");
  };

  const generateAIResponse = (userMessage) => {
    userMessage = userMessage.toLowerCase();
  
    if (userMessage.includes("hello") || userMessage.includes("hi")) {
      return "Hello! How can I assist you today? 😊";
    }
    if (userMessage.includes("help")) {
      return "Sure! I can help with anything related to this chat app.";
    }
    if (userMessage.includes("your name")) {
      return "I'm your AI assistant! 🤖";
    }
    if (userMessage.includes("bye")) {
      return "Goodbye! Have a great day. 👋";
    }
  
    return "I'm still learning! Ask me something else. 😊";
  };
  

  const formatDate = (timestamp) => {
    if (!timestamp) return "";
    return new Date(timestamp.seconds * 1000).toLocaleDateString();
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return "";
    return new Date(timestamp.seconds * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="chat-container">
      <Header toggleSidebar={toggleSidebar} />
      <div className="chat-content">
        <Sidebar isOpen={sidebarOpen} />
        <div className={`chat-main ${sidebarOpen ? 'sidebar-visible' : 'sidebar-hidden'}`}>
        <div className="chat-sidebar">
  <h2 className="Contact">Contacts</h2>
  
  {/* Search Input */}
  <input
    type="text"
    className="search-bar"
    placeholder="Search contacts..."
    value={searchQuery}
    onChange={(e) => setSearchQuery(e.target.value)}
  />
  <ul>
              {[...pinnedContacts, ...users.filter(user => !pinnedContacts.some(pinned => pinned.uid === user.uid))]
                .filter(user => user.username.toLowerCase().includes(searchQuery.toLowerCase()))
                .filter(user => user.uid !== currentUser?.uid)
                .map(user => (
                  <li key={user.uid} className={selectedUser?.uid === user.uid ? "active" : ""}>
                    <span onClick={() => setSelectedUser(user)}>{user.username}</span>
                    <span className="dropdown-icon" onClick={() => toggleDropdown(user.uid)}>⋮</span>
                    {dropdownOpen === user.uid && (
                      <div className="dropdown-menu">
                        <button className= "pin" onClick={() => pinContact(user)}>📌 Pin Contact</button>
                      </div>
                    )}
                  </li>
              ))}
            </ul>
          </div>

          <div className="chat-box">
            {selectedUser ? (
              <>
                <div className="chat-header">
                  <h2>{selectedUser.username}</h2>
                </div>
                <div className="chat-messages">
                  {messages.map((msg, index) => {
                    const prevDate = index > 0 ? formatDate(messages[index - 1].timestamp) : null;
                    const currentDate = formatDate(msg.timestamp);
                    const showDate = prevDate !== currentDate;
                    
                    return (
                      <div key={index} className="message-container">
                        {showDate && <div className="chat-date">{currentDate}</div>}

                        {/* User Name Outside Message */}
                        <div className={`message-sender ${msg.sender === currentUser.uid ? "sender" : msg.sender === "ai-bot" ? "ai-message" : "receiver"}`}>
                          {msg.sender === currentUser.uid ? "You" : msg.sender === "ai-bot" ? "AI Assistant" : selectedUser.username}
                        </div>

                        {/* Message Bubble */}
                        <div className={`message ${msg.sender === currentUser.uid ? "sent" : "received"}`}>
                          {msg.message}
                          <div className="message-timestamp">{formatTime(msg.timestamp)}</div>
                        </div>

                        {/* Timestamp Below Message */}
                        
                      </div>
                    );
                  })}
                </div>
                <div className="chat-input">
                  <input 
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                  />
                  <button onClick={sendMessage}>Send</button>
                </div>
              </>
            ) : (
              <div className="no-chat-selected">Select a user to start chatting</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
