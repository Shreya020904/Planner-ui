import React, { useState } from "react";
import { auth, db } from "../firebase";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { collection, addDoc, query, where, getDocs } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

const Login = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("username", "==", username));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        setError("Username not found!");
        return;
      }

      const userData = querySnapshot.docs[0].data();
      const userEmail = userData.email;

      await signInWithEmailAndPassword(auth, userEmail, password);
      localStorage.setItem("username", username); // Store username in localStorage
      navigate("/dashboard");
    } catch (error) {
      setError("Invalid username or password!");
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await addDoc(collection(db, "users"), { username, email, uid: userCredential.user.uid });
      setIsSignUp(false); // Switch to login form automatically
      setError("");
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="slider-container">
          <div className={`slider ${isSignUp ? "signup" : "login"}`} />
          <button className={!isSignUp ? "active" : ""} onClick={() => setIsSignUp(false)}>Login</button>
          <button className={isSignUp ? "active" : ""} onClick={() => setIsSignUp(true)}>Sign Up</button>
        </div>

        {isSignUp ? (
          <form className="form-container" onSubmit={handleSignup}>
            <h2 className="heading">Sign Up</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}
            <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button type="submit">Sign Up</button>
          </form>
        ) : (
          <form className="form-container" onSubmit={handleLogin}>
            <h2 className="heading">Login</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}
            <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button type="submit">Login</button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;
