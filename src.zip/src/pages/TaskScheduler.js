import React, { useState } from "react";
import "./TaskScheduler.css";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";

const TaskScheduler = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [taskName, setTaskName] = useState("");
  const [taskType, setTaskType] = useState("Meeting");
  const [taskDate, setTaskDate] = useState("");
  const [taskTime, setTaskTime] = useState("");

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Task Scheduled:", { taskName, taskType, taskDate, taskTime });
    setTaskName("");
    setTaskDate("");
    setTaskTime("");
  };

  return (
    <div className="task-container">
      <Header toggleSidebar={toggleSidebar} />
      <div className="task-content">
        <Sidebar isOpen={sidebarOpen} />
        <main className={`task-main ${sidebarOpen ? 'sidebar-visible' : 'sidebar-hidden'}`}>
          <h2>Schedule a Task</h2>
          <form onSubmit={handleSubmit} className="task-form">
            <input 
              type="text" 
              placeholder="Task Name" 
              value={taskName} 
              onChange={(e) => setTaskName(e.target.value)}
              required 
            />
            <select value={taskType} onChange={(e) => setTaskType(e.target.value)}>
              <option value="Meeting">Meeting</option>
              <option value="Task">Task</option>
              <option value="Issue Sorting">Issue Sorting</option>
            </select>
            <input 
              type="date" 
              value={taskDate} 
              onChange={(e) => setTaskDate(e.target.value)}
              required 
            />
            <input 
              type="time" 
              value={taskTime} 
              onChange={(e) => setTaskTime(e.target.value)}
              required 
            />
            <button type="submit">Schedule Task</button>
          </form>
        </main>
      </div>
    </div>
  );
};

export default TaskScheduler;